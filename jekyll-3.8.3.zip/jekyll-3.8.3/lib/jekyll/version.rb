# frozen_string_literal: true

module Jekyll
  VERSION = "3.8.3".freeze
end
